#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════
#  setup.sh — INSTALARE COMPLETĂ (rulează o singură dată)
#  Instalează tot ce trebuie, configurează, și verifică.
# ════════════════════════════════════════════════════════════
set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "╔══════════════════════════════════════════════╗"
echo "║   PhotoSync — instalare completă              ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── 0. Verific Node.js ──────────────────────────────────────
if ! command -v node >/dev/null 2>&1; then
    echo "❌ Node.js nu e instalat. Instalează de pe https://nodejs.org (LTS)."
    exit 1
fi
echo "✓ Node.js: $(node -v)"
echo "✓ npm:     $(npm -v)"
echo ""

# ── 1. SERVER ───────────────────────────────────────────────
echo "════ [1/4] Instalez SERVER ════"
cd "$ROOT/server"

# Șterge node_modules vechi pentru instalare curată (tfjs poate fi corupt)
if [ -d node_modules ]; then
    echo "   Curăț node_modules vechi..."
    rm -rf node_modules package-lock.json
fi

echo "   Instalez dependențe (1-2 min)..."
# tfjs-node și sharp sunt optional → npm NU eșuează dacă pică
npm install --no-audit --no-fund 2>&1 | tail -3

echo ""
echo "   Încerc accelerare nativă TensorFlow (best-effort)..."
npm rebuild @tensorflow/tfjs-node 2>&1 | tail -2 || echo "   (opțional, continui pe CPU)"
echo "   ✅ Server instalat."
echo ""

# ── 2. CLIENT ───────────────────────────────────────────────
echo "════ [2/4] Instalez CLIENT ════"
cd "$ROOT/client"
if [ -d node_modules ]; then
    echo "   Curăț node_modules vechi..."
    rm -rf node_modules package-lock.json
fi
echo "   Instalez dependențe (1-2 min)..."
npm install --no-audit --no-fund 2>&1 | tail -3
echo "   ✅ Client instalat."
echo ""

# ── 3. .ENV ─────────────────────────────────────────────────
echo "════ [3/4] Configurare .env ════"
cd "$ROOT"
[ -f server/.env ] || cp server/.env.example server/.env
[ -f client/.env ] || cp client/.env.example client/.env
echo "   ✅ .env create."
echo ""

# ── 4. VERIFICARE ───────────────────────────────────────────
echo "════ [4/4] Verificare backend AI ════"
cd "$ROOT/server"
node -e "require('./services/faceService')" 2>&1 | grep -iE 'Backend|nativ|fallback' || true
echo ""

# ── Sumar ───────────────────────────────────────────────────
echo "╔══════════════════════════════════════════════╗"
echo "║  ✅  INSTALARE COMPLETĂ                       ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "  ⚠️  ULTIMUL PAS MANUAL:"
echo "     Deschide  server/.env  și setează:"
echo "        ALLOWED_SCAN_ROOT=/Users/morarucatalin/Pictures"
echo "     (folderul cu poze; fără asta scanarea locală e blocată)"
echo ""
echo "  ▶  PORNEȘTE aplicația:"
echo "     Terminal 1:  cd server && npm run dev"
echo "     Terminal 2:  cd client && npm run dev"
echo "     Apoi:        http://localhost:5173"
echo ""
echo "  Dacă vrei accelerare nativă (mai rapid):  bash scripts/fix-tensorflow.sh"
echo ""
