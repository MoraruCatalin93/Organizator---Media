#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════
#  fix-tensorflow.sh
#  Repară eroarea "Library not loaded: libtensorflow.2.dylib"
#  pe macOS / Linux. Rebuild-uiește binding-ul nativ tfjs-node.
#  Non-fatal: dacă nu merge, aplicația folosește automat CPU.
# ════════════════════════════════════════════════════════════
set -e

cd "$(dirname "$0")/.."   # mergem în rădăcina server/
cd server 2>/dev/null || { echo "Rulează din rădăcina proiectului."; exit 1; }

echo "🔧 [1/3] Verific Node.js..."
NODE_MAJOR=$(node -p 'process.versions.node.split(".")[0]')
echo "   Node v$(node -v)  (major: $NODE_MAJOR)"

echo ""
echo "🔧 [2/3] Rebuild binding nativ tfjs-node (redescarcă libtensorflow)..."
# --build-addon-from-source compilează local dacă binarul prebuilt lipsește
npm rebuild @tensorflow/tfjs-node 2>&1 | tail -5 || {
    echo "   ⚠️  rebuild standard a eșuat, încerc din sursă..."
    npm rebuild @tensorflow/tfjs-node --build-addon-from-source 2>&1 | tail -5 || true
}

echo ""
echo "🔧 [3/3] Verific că librăria libtensorflow există..."
FOUND=$(find node_modules/@tensorflow/tfjs-node/deps/lib -type f 2>/dev/null | head -1 || true)
if [ -n "$FOUND" ]; then
    echo "   ✅ Librărie găsită: $FOUND"
    echo "   Backend nativ disponibil."
else
    echo "   ⚠️  Librăria nativă NU s-a putut instala."
    echo "      NU e problemă: aplicația rulează pe backend CPU (mai lent)."
    echo "      Recunoașterea funcționează, doar procesarea e ceva mai lentă."
fi

echo ""
echo "✅ Verificare finală — care backend se încarcă:"
node -e "require('./services/faceService')" 2>&1 | grep -E 'Backend|fallback|nativ' || echo "   (vezi mesajul de la pornirea serverului)"

echo ""
echo "Gata. Pornește serverul:  npm run dev"
