#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════
#  dev.sh — pornește SERVER + CLIENT simultan
#  Oprește ambele cu Ctrl+C
# ════════════════════════════════════════════════════════════
ROOT="$(cd "$(dirname "$0")" && pwd)"

trap 'kill 0' INT EXIT

echo "🟢 Pornesc server (port 5001)..."
(cd "$ROOT/server" && npm run dev) &
SERVER_PID=$!

echo "🟢 Pornesc client (port 5173)..."
(cd "$ROOT/client" && npm run dev) &

echo ""
echo "═══════════════════════════════════════"
echo "  Aplicația: http://localhost:5173"
echo "  Oprește cu Ctrl+C"
echo "═══════════════════════════════════════"
echo ""

wait
