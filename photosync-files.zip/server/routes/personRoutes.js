const express = require('express');
const multer = require('multer');
const fs = require('fs-extra');
const { getFaceDescriptor } = require('../services/faceService');
const { addPerson, getDatabase, saveDatabase, deletePerson, countDescriptors } = require('../services/storageService');

const router = express.Router();

const MAX_UPLOAD_MB = parseInt(process.env.MAX_UPLOAD_MB || '25', 10);

const upload = multer({
    dest: 'uploads/',
    limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
        if (/\.(jpe?g|png|webp|gif|bmp|tiff?)$/i.test(file.originalname)) return cb(null, true);
        cb(new Error('Doar imagini (JPG, PNG, WEBP, GIF, BMP, TIFF).'));
    }
});

router.get('/', (req, res) => {
    try {
        const db = getDatabase();
        const persons = Object.entries(db.persons).map(([name, descriptors]) => ({
            name,
            samples: countDescriptors(descriptors)
        }));
        res.json({ persons });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

router.post('/', upload.single('image'), async (req, res) => {
    try {
        const { name } = req.body;
        if (!name || !req.file) {
            return res.status(400).json({ error: 'Name and image are required' });
        }

        const imageBuffer = await fs.readFile(req.file.path);
        
        // Extract face descriptor
        const descriptor = await getFaceDescriptor(imageBuffer);
        
        // Save to DB
        addPerson(name, [descriptor]);

        // Cleanup
        await fs.remove(req.file.path);

        res.json({ success: true, message: `Person ${name} added successfully.` });
    } catch (error) {
        console.error('Error adding person:', error);
        if (req.file) await fs.remove(req.file.path);
        res.status(500).json({ error: error.message });
    }
});

// Delete a person and all their face descriptors
router.delete('/:name', (req, res) => {
    try {
        const { name } = req.params;
        const deleted = deletePerson(name);
        if (!deleted) return res.status(404).json({ error: 'Persoana nu a fost găsită.' });
        res.json({ success: true, message: `Persoana ${name} a fost ștearsă.` });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

module.exports = router;
