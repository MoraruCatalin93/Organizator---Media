const express = require('express');
const config = require('../config');
const { getStorageProvider } = require('../storage');

const router = express.Router();

const IMAGE_RE = /\.(jpe?g|png|webp|gif|bmp|tiff?|avif)$/i;

/**
 * GET /api/gallery
 * Lists the organized output tree:
 *   { persons: [ { name, count, files: [{ name, path }] } ] }
 */
router.get('/', async (_req, res) => {
    try {
        const provider = getStorageProvider(config.storageTarget);
        const entries = await provider.list('');
        const persons = [];

        for (const entry of entries) {
            if (!entry.isDir) continue;
            const files = await provider.list(entry.path);
            const images = files
                .filter(f => !f.isDir && IMAGE_RE.test(f.name))
                .map(f => ({ name: f.name, path: f.path }));
            if (images.length === 0) continue;
            persons.push({ name: entry.name, count: images.length, files: images });
        }

        // Newest-sorted: most photos first
        persons.sort((a, b) => b.count - a.count);

        res.json({ persons, totalImages: persons.reduce((s, p) => s + p.count, 0) });
    } catch (e) {
        console.error('Gallery list error:', e);
        res.status(500).json({ error: e.message });
    }
});

module.exports = router;
