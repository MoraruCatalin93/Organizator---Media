const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const config = require('../config');
const { getStorageProvider } = require('../storage');
const { withJpgExt } = require('../services/imageService');
const { processImageFile, copyImageToFolders, getDatabase } = require('../services/storageService');
const { hasCredentials, isAuthenticated, getAuthUrl, getAccessToken } = require('../services/driveService');

const router = express.Router();

const MAX_UPLOAD_MB = config.maxUploadMb;
const ALLOWED_IMAGE_RE = /\.(jpe?g|png|webp|gif|bmp|tiff?|heic|heif|avif)$/i;

// Multer: size limit + file count + image-only filter
const upload = multer({
    dest: 'uploads/',
    limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 50 },
    fileFilter: (_req, file, cb) => {
        if (ALLOWED_IMAGE_RE.test(file.originalname)) return cb(null, true);
        cb(new Error(`Tip de fișier neacceptat: ${file.originalname}`));
    }
});

/**
 * Resolve and validate a user-supplied folder path so the server can only
 * read inside ALLOWED_SCAN_ROOT (prevents path traversal / arbitrary file access).
 */
function resolveSafePath(rawPath) {
    if (!rawPath || typeof rawPath !== 'string') {
        throw new Error('Cale invalidă.');
    }
    const root = process.env.ALLOWED_SCAN_ROOT;
    if (!root) {
        throw new Error('Scanarea folderelor locale este dezactivată. Setează ALLOWED_SCAN_ROOT pe server.');
    }
    const resolved = path.resolve(rawPath);
    const rootResolved = path.resolve(root);
    // Reject any attempt to escape the allowed root via ".." or absolute paths outside it
    const rel = path.relative(rootResolved, resolved);
    if (rel.startsWith('..') || path.isAbsolute(rel)) {
        throw new Error('Acces refuzat: calea este în afara zonei permise.');
    }
    return resolved;
}

router.post('/local', async (req, res) => {
    const { folderPath } = req.body;
    if (!folderPath) {
        return res.status(400).json({ error: 'Folder path is required' });
    }

    try {
        const safePath = resolveSafePath(folderPath);

        if (!fs.existsSync(safePath)) {
            return res.status(400).json({ error: 'Folder does not exist' });
        }

        const files = await fs.readdir(safePath);
        const imageFiles = files.filter(f => ALLOWED_IMAGE_RE.test(f));
        
        const db = getDatabase();
        const provider = getStorageProvider(config.storageTarget);
        const results = [];

        for (const file of imageFiles) {
            const fullPath = path.join(safePath, file);
            const { matched, storeBuffer, converted } = await processImageFile(fullPath, db);
            const storeName = converted ? withJpgExt(file) : file;
            await copyImageToFolders(storeBuffer, matched, storeName, provider);
            results.push({ file, matched });
        }

        res.json({ success: true, processed: results.length, total: imageFiles.length, results });
    } catch (error) {
        console.error('Error processing local folder:', error);
        const status = error.message.includes('permisă') || error.message.includes('dezactivată') ? 403 : 500;
        res.status(status).json({ error: error.message });
    }
});

router.post('/upload', upload.array('images'), async (req, res) => {
    try {
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ error: 'No files uploaded' });
        }

        const db = getDatabase();
        const provider = getStorageProvider(config.storageTarget);
        const results = [];

        for (const file of req.files) {
            const { matched, storeBuffer, converted } = await processImageFile(file.path, db);
            const storeName = converted ? withJpgExt(file.originalname) : file.originalname;
            await copyImageToFolders(storeBuffer, matched, storeName, provider);
            await fs.remove(file.path);
            results.push({ file: file.originalname, matched });
        }

        res.json({ success: true, processed: results.length, total: req.files.length, results });
    } catch (error) {
        console.error('Error processing uploads:', error);
        if (req.files) {
            for (const file of req.files) {
                await fs.remove(file.path);
            }
        }
        res.status(500).json({ error: error.message });
    }
});

// ────────────────────────────────────────────────────────────
// SSE streaming scan of a local folder — emits live progress events.
//   events: 'start' {total} · 'progress' {index,total,file,matched}
//           'done' {processed,total,results} · 'error' {error}
// ────────────────────────────────────────────────────────────
router.post('/local/stream', async (req, res) => {
    const { folderPath } = req.body;

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    const send = (event, data) => {
        res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    };

    const cleanup = () => { try { res.end(); } catch (_) {} };
    req.on('close', cleanup);

    try {
        const safePath = resolveSafePath(folderPath);
        if (!fs.existsSync(safePath)) {
            send('error', { error: 'Folderul nu există.' });
            return cleanup();
        }

        const all = await fs.readdir(safePath);
        const imageFiles = all.filter(f => ALLOWED_IMAGE_RE.test(f));
        send('start', { total: imageFiles.length });

        const db = getDatabase();
        const provider = getStorageProvider(config.storageTarget);
        const results = [];

        for (let i = 0; i < imageFiles.length; i++) {
            const file = imageFiles[i];
            const fullPath = path.join(safePath, file);
            const { matched, storeBuffer, converted } = await processImageFile(fullPath, db);
            const storeName = converted ? withJpgExt(file) : file;
            await copyImageToFolders(storeBuffer, matched, storeName, provider);
            results.push({ file, matched });
            send('progress', { index: i + 1, total: imageFiles.length, file, matched });
        }

        send('done', { processed: results.length, total: imageFiles.length, results });
    } catch (error) {
        console.error('Error streaming local folder:', error);
        send('error', { error: error.message });
    } finally {
        cleanup();
    }
});

// Drive Routes
router.get('/drive/status', (req, res) => {
    res.json({ 
        hasCredentials: hasCredentials(), 
        isAuthenticated: isAuthenticated(),
        authUrl: !isAuthenticated() && hasCredentials() ? getAuthUrl() : null
    });
});

router.post('/drive/callback', async (req, res) => {
    try {
        const { code } = req.body;
        if (!code) return res.status(400).json({ error: 'Code is required' });
        await getAccessToken(code);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
