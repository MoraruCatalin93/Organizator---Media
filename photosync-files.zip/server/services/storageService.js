const fs = require('fs-extra');
const path = require('path');
const { getAllFaces, findBestMatch } = require('./faceService');
const { prepareImage } = require('./imageService');
const { getStorageProvider } = require('../storage');
const config = require('../config');

const OUTPUT_DIR = config.outputDir;
const DATA_FILE = path.join(__dirname, '../data/db.json');

// Ensure directories exist
fs.ensureDirSync(OUTPUT_DIR);
fs.ensureDirSync(path.dirname(DATA_FILE));

// Initialize DB if doesn't exist
if (!fs.existsSync(DATA_FILE)) {
    fs.writeJsonSync(DATA_FILE, { persons: {} });
}

function getDatabase() {
    return fs.readJsonSync(DATA_FILE);
}

function saveDatabase(data) {
    fs.writeJsonSync(DATA_FILE, data, { spaces: 2 });
}

function addPerson(name, descriptors) {
    const db = getDatabase();
    if (!db.persons[name]) {
        db.persons[name] = [];
    }
    // Convert Float32Array to standard array for JSON serialization
    const serializableDescriptors = descriptors.map(desc => Array.from(desc));
    db.persons[name].push(...serializableDescriptors);
    saveDatabase(db);
}

function getPersons() {
    const db = getDatabase();
    return Object.keys(db.persons);
}

function deletePerson(name) {
    const db = getDatabase();
    if (!db.persons[name]) return false;
    delete db.persons[name];
    saveDatabase(db);
    return true;
}

// Count total descriptor entries for a person's record.
// Handles both arrays of descriptors (flat) and any nested shape defensively.
function countDescriptors(descriptors) {
    if (!Array.isArray(descriptors)) return 0;
    return descriptors.length;
}

// Helper to determine the destination folder(s) for one image.
// Returns { matched, storeBuffer, converted }.
async function processImageFile(imagePath, db) {
    const raw = await fs.readFile(imagePath);

    // Normalize: EXIF auto-orient + HEIC→JPEG (for detection).
    // storeBuffer keeps the ORIGINAL unless it was HEIC (then the JPEG).
    let detectBuffer = raw;
    let storeBuffer = raw;
    let converted = false;
    try {
        ({ detectBuffer, storeBuffer, converted } = await prepareImage(raw));
    } catch (e) {
        console.warn(`[prepareImage] fallback la buffer brut pentru ${imagePath}: ${e.message}`);
    }

    try {
        const detections = await getAllFaces(detectBuffer);

        if (detections.length === 0) {
            return { matched: ['Unknown'], storeBuffer, converted }; // No faces
        }

        const matchedNames = new Set();

        for (const detection of detections) {
            const match = findBestMatch(detection.descriptor, db.persons);
            if (match) {
                matchedNames.add(match.label);
            }
        }

        if (matchedNames.size === 0) {
            return { matched: ['Unknown'], storeBuffer, converted }; // Faces detected but unknown
        }

        // Single match or group photo (one entry per known person)
        return { matched: Array.from(matchedNames), storeBuffer, converted };

    } catch (e) {
        console.error(`Error processing image ${imagePath}:`, e);
        return { matched: ['Errors'], storeBuffer, converted };
    }
}

// Write the (already-prepared) buffer into each target person's folder
// through the active storage provider (local / drive / s3).
async function copyImageToFolders(buffer, targetFolders, fileName, provider) {
    const store = provider || getStorageProvider(config.storageTarget);
    for (const folderName of targetFolders) {
        await store.write(path.join(folderName, fileName), buffer);
    }
}

module.exports = {
    addPerson,
    getPersons,
    getDatabase,
    saveDatabase,
    deletePerson,
    countDescriptors,
    processImageFile,
    copyImageToFolders,
    OUTPUT_DIR
};
